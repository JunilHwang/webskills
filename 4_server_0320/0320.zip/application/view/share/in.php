<form action="" method="post">
	<fieldset>
		<legend>내부공유</legend>
		<ul>
			<li>
				<label>
					공유 주소 입력 : 
					<input type="text" name="url">
				</label>
			</li>
		</ul>
	</fieldset>
</form>