<form action="" method="post">
	<fieldset>
		<legend>LOGIN</legend>
		<input type="hidden" name="action" value="login">
		<input type="text" name="id" size="20" placeholder="id" autofocus="">
		<input type="password" name="pw" size="20" placeholder="pw">
		<button type="submit">Login</button>
	</fieldset>
</form>